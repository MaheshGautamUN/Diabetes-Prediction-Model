from flask import Flask, render_template, request, redirect, url_for, flash
import numpy as np
import joblib
import os


app = Flask(__name__)
app.secret_key = os.urandom(24)


# Load model and scaler (ensure these files are in the same folder)
MODEL_PATH = 'diabetes_model.pkl'
SCALER_PATH = 'scaler.pkl'


model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)


FEATURES = [
'Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness',
'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age'
]


@app.route('/')
def home():
	return render_template('index.html', features=FEATURES)


@app.route('/predict', methods=['POST'])
def predict():
	try:
		# Read form inputs in the same order as FEATURES
		values = []
		for f in FEATURES:
			raw = request.form.get(f)
			if raw is None or raw.strip() == '':
				flash(f'Missing value for {f}. Please fill all fields.', 'danger')
				return redirect(url_for('home'))
			# Convert to float
			val = float(raw)
			values.append(val)

		X = np.array(values).reshape(1, -1)
		X_scaled = scaler.transform(X)

		prob = model.predict_proba(X_scaled)[0][1]
		pred = int(model.predict(X_scaled)[0])

		return render_template('result.html', probability=round(prob, 4), prediction=pred)

	except Exception as e:
		flash('Error during prediction: ' + str(e), 'danger')
		return redirect(url_for('home'))


if __name__ == '__main__':
	app.run(debug=True)