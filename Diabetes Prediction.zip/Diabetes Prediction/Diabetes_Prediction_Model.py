# Diabetes prediction model using data science and machine learning

# Step 1: Import Libraries

# Basic runtime configuration
Warning.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Project data path
DATA_PATH = Path(r"C:\Users\mahes\OneDrive - United Nations\Data Science course Naresh\3 Data Science\Projects\Diabetes Prediction")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
import os
import sys
from pathlib import Path
import logging
import warnings


# Step 2: Load Dataset
df = pd.read_csv(r"C:\Users\mahes\OneDrive - United Nations\Data Science course Naresh\3 Data Science\Projects\Diabetes Prediction\diabetes.csv")
df.head()
df.info()
df.isnull().sum()

# Step 3: Clean & Preprocess Data
cols_with_zero = ['Glucose','BloodPressure','SkinThickness','Insulin','BMI']
for col in cols_with_zero:
    df[col] = df[col].replace(0, np.nan)

df.fillna(df.mean(), inplace=True)
